package com.vibrantminds.StoreApp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.vibrantminds.StoreApp.Dao.ProductRepository;
import com.vibrantminds.StoreApp.domain.Product;

@SpringBootApplication
public class StoreAppApplication implements CommandLineRunner   {
	
	
	@Autowired
	private ProductRepository repository;
	
	
	public static void main(String[] args) {
		SpringApplication.run(StoreAppApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		repository.save(new Product(null,"F1",12345.678,"E1","C1"));
		repository.save(new Product(null,"F2",12345.678,"E2","C2"));
		repository.save(new Product(null,"F3",12345.678,"E3","C3"));
		repository.save(new Product(null,"F4",12345.678,"E4","C4"));
		repository.save(new Product(null,"F5",12345.678,"E5","C5"));
		repository.save(new Product(null,"F6",12345.678,"E6","C6"));
		repository.save(new Product(null,"F7",12345.678,"E7","C7"));
		repository.save(new Product(null,"F8",12345.678,"E8","C8"));
		repository.save(new Product(null,"F9",12345.678,"E9","C9"));
		repository.save(new Product(null,"F10",12345.678,"E10","C10"));
		repository.save(new Product(null,"F11",12345.678,"E11","C11"));
		
	}
		
	}
	
	
	
	
	
	
